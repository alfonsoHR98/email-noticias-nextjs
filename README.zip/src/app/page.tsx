"use client";
import React from "react";
import SideBar from "@components/SideBar";
import NewCard from "@components/New-Card";
import { useNotice } from "@context/NoticeContext";

export default function Home() {
  const { notices } = useNotice();
  return (
    <div className="w-full h-full flex flex-col">
      <SideBar />
      <main className="mt-4 mx-auto w-4/5 flex-1 flex flex-col gap-4 items-center justify-start overflow overflow-hidden">
        {notices.length > 0 ? (
          notices.map((elemento, index) => (
            <NewCard key={index} elemento={elemento} />
          ))
        ) : (
          <p>No hay noticias</p>
        )}
      </main>
    </div>
  );
}

